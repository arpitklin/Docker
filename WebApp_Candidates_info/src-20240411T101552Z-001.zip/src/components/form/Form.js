import React, { useState, useEffect } from 'react';
import './Form.css';

const CoolForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        address: ''
    });

    const [records, setRecords] = useState([]);

    useEffect(() => {
        fetchData();
    }, []);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('YOUR_BACKEND_URL', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            if (response.ok) {
                console.log('Form submitted successfully');
                fetchData(); // Refresh records after submission
                setFormData({
                    name: '',
                    email: '',
                    phone: '',
                    address: ''
                });
            } else {
                console.error('Form submission failed:', response.statusText);
            }
        } catch (error) {
            console.error('Error submitting form:', error);
        }
    };

    const fetchData = async () => {
        try {
            const response = await fetch('YOUR_BACKEND_URL');
            if (response.ok) {
                const data = await response.json();
                setRecords(data);
            } else {
                console.error('Failed to fetch data:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    return (
        <div className="cool-form-container">
            <form onSubmit={handleSubmit} className="cool-form">
                <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Name"
                    required
                />
                <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="Email"
                    required
                />
                <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="Phone"
                    pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                    required
                />
                <textarea
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="Address"
                    required
                ></textarea>
                <button type="submit">Submit</button>
            </form>

            <div className="records-container">
                <h2>Records</h2>
                <ul>
                    {records.map((record, index) => (
                        <li key={index}>
                            <strong>Name:</strong> {record.name}, <strong>Email:</strong> {record.email}, <strong>Phone:</strong> {record.phone}, <strong>Address:</strong> {record.address}
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default CoolForm;
