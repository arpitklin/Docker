import logo from "./logo.svg";
import "./App.css";
import CoolForm from "./components/form/Form.js";

function App() {
  return (
    <div className="App">
      <CoolForm />
    </div>
  );
}

export default App;
