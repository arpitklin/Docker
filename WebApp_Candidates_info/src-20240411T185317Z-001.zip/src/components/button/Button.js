import React from "react";
import "./Button.css"; // assuming you've saved the CSS file as Button.css in the same directory as this component

const Button = () => {
  return (
    <button class="button-89" role="button" >
      REGISTER
    </button>
  );
};

export default Button;
