import React, { useState, useEffect } from "react";
import "./Form.css";

const CoolForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });

  const [records, setRecords] = useState([]);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [errorModalMessage, setErrorModalMessage] = useState("");

  useEffect(() => {
    fetchData();
    console.log("records", records);
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(
        "https://to-do-list-1808a-default-rtdb.firebaseio.com/Xyz.json",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );
      if (response.ok) {
        console.log("Form submitted successfully");
        fetchData(); // Refresh records after submission
        setShowSuccessModal(true); // Show success modal on successful submission
        setFormData({
          name: "",
          email: "",
          phone: "",
          address: "",
        });
      } else {
        console.error("Form submission failed:", response.statusText);
        setErrorModalMessage("Error submitting form: " + response.statusText);
        setShowErrorModal(true); // Show error modal on failed submission
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setErrorModalMessage("Error submitting form: " + error.message);
      setShowErrorModal(true); // Show error modal on exception
    }
  };

  const fetchData = async () => {
    try {
      const response = await fetch(
        "https://to-do-list-1808a-default-rtdb.firebaseio.com/Xyz.json"
      );
      if (response.ok) {
        const data = await response.json();
        setRecords(data); // Update records with fetched data
      } else {
        console.error("Failed to fetch data:", response.statusText);
        setErrorModalMessage("Failed to fetch data: " + response.statusText);
        setShowErrorModal(true); // Show error modal on failed fetch
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setErrorModalMessage("Error fetching data: " + error.message);
      setShowErrorModal(true); // Show error modal on exception
    }
  };

  const handleDelete = async (id) => {
    try {
      const response = await fetch(
        `https://to-do-list-1808a-default-rtdb.firebaseio.com/Xyz/${id}.json`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        console.log("Record deleted successfully");
        fetchData(); // Refresh records after deletion
      } else {
        console.error("Failed to delete record:", response.statusText);
        setErrorModalMessage("Failed to delete record: " + response.statusText);
        setShowErrorModal(true);
      }
    } catch (error) {
      console.error("Error deleting record:", error);
      setErrorModalMessage("Error deleting record: " + error.message);
      setShowErrorModal(true);
    }
  };

  return (
    <div className="cool-form-container">
      <form onSubmit={handleSubmit} className="cool-form">
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          placeholder="Name"
          required
        />
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          placeholder="Email"
          required
        />
        <input
          type="tel"
          name="phone"
          value={formData.phone}
          onChange={handleChange}
          placeholder="Phone"
          required
        />
        <textarea
          name="address"
          value={formData.address}
          onChange={handleChange}
          placeholder="Address"
          required
        ></textarea>
        <button type="submit">Submit</button>
      </form>

      <div className="records-container">
        <h2>Records</h2>

        {Object.keys(records).length === 0 ? (
          <p>No records found</p>
        ) : (
          <ul>
            {Object.entries(records).map(([id, record]) => (
              <li key={id} className="records">
                <span>
                  <strong>Name:</strong> {record.name}
                  <br />
                  <strong>Email:</strong> {record.email}
                  <br />
                </span>

                <button onClick={() => handleDelete(id)}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="modal modal-success">
          <div className="modal-content">
            <span className="close" onClick={() => setShowSuccessModal(false)}>
              &times;
            </span>
            <p>Record submitted successfully!</p>
          </div>
        </div>
      )}

      {/* Error Modal */}
      {showErrorModal && (
        <div className="modal modal-error">
          <div className="modal-content">
            <span className="close" onClick={() => setShowErrorModal(false)}>
              &times;
            </span>
            <p>{errorModalMessage}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default CoolForm;
